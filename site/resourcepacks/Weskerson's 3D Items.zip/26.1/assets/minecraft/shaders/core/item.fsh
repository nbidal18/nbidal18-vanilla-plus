#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightColor; // From VSH
in vec4 baseColor;  // From VSH
in vec2 texCoord0;
out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;
    
// Replace your existing ivec4 ich line with:
vec4 texColor = texture(Sampler0, texCoord0);
int currentAlpha = int(round(texColor.a * 255.0));

switch (currentAlpha) {
    case 254: 
        color *= baseColor; 
        break;
        
    case 200: 
    case 250:
    case 252: 
    case 253: 
    case 100: 
    case 50: 
        color *= lightColor; 
        color.rgb *= 0.9; 
        break;
        
    default: 
        // Blend between full vanilla shading and flat unshaded lighting
        color *= mix(vertexColor, lightColor, 0.2); 
        break;
}

    // Alpha cutout to prevent invisible pixels from rendering incorrectly
    if (color.a < 0.1) discard;

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}