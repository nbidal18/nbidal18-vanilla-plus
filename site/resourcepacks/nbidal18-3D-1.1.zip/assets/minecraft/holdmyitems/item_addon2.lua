local l = (bl and 1) or -1
local d = (bl and 1) or -0.8

local items = {
  "minecraft:diamond_block",
  "minecraft:gold_block"
}

for i, id in pairs(items) do
    if I:isOf(item, Items:get(id)) then
        renderAsBlock:put(id, false)
    M:scale(matrices,1,1,1)
        M:rotateX(matrices, -55)
        M:rotateY(matrices, -37*d)
    M:rotateZ(matrices, -60*l)
        M:moveX(matrices, 0.4*l)
    M:moveZ(matrices, 0.4)
	M:moveY(matrices, -0.3)
    end
end