# Sources

Nothing in this pack is our artwork. It is a build-time merge of four published resource packs,
for use inside the nbidal18 Vanilla+ modpack only, plus generated item definitions and copies of
vanilla Minecraft assets. Rebuilt by `scripts\Build-3DPack.ps1` from the archives in
`5. modpack source\custom packs\nbidal18-3D\sources\`; nothing in it is edited by hand.

| Source | Author | Where | Files used here |
| --- | --- | --- | --- |
| Weskerson's 3D Items 2.5 | Weskerson | https://modrinth.com/resourcepack/weskersons-3d-items | 792 |
| Weskerson's 3D Food 1.0 | Weskerson | https://modrinth.com/resourcepack/weskersons-3d-food | 571 |
| Weskerson's Torches 1.02 (core item shader already stripped, see below) | Weskerson | https://modrinth.com/resourcepack/weskersons-torches | 128 |
| Actually 3D Blocks & Items r1.8 | Matt_Crowberry | https://modrinth.com/resourcepack/actually-3d | 1713 |
| Minecraft 26.2 (Mojang) - model and texture copies under `nbidal18/vanilla/` so the inventory draws exactly what vanilla draws | Mojang Studios | the game jar | 1692 |
| generated here | nbidal18 | this build | 942 |

## What the build changes

- The four packs are flattened (root assets plus any overlay that applies to resource format 88) and merged in the order the client used to apply them: Weskerson's 3D Items, then 3D Food, then Torches, then Actually 3D on top.
- Actually 3D's models for block names that Better Lanterns or Weskerson's Torches also ship are dropped, so those two keep their categories.
- Weskerson's Torches had its core item shader removed before it was archived here: on 26.2 that shader stopped every item sprite from drawing.
- Weskerson's crimson and warped hanging-sign definitions are dropped; they pointed at a hand model no pack ships.
- For every item whose inventory rendering would differ from vanilla's, a definition sends the inventory to a private copy of vanilla's own model and textures, and every other context to the 3D model. For every 3D item a source sent flat to the ground or into item frames, those contexts are sent to the 3D model, with transforms sized from its geometry where the model had none.
- Credits, title-screen art, shaders, optimiser residue and other packs' namespaces are not carried.
